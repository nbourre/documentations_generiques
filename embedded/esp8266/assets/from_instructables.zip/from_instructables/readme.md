Firmware source : https://www.instructables.com/ESP8266-ESP-12E-UART-Wireless-WIFI-Shield-TTL-Conv/
Ai-Thinker_ESP8266_DOUT_32Mbit_v1.5.4.1-a_20171130.bin

Firmware source : https://docs.ai-thinker.com/en/esp8266/sdk
BAT_AT_V1.7.1.0_4M.bin
